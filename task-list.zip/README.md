# Setup

## Software requirements

- Node.js
- MongoDB

## Install dependencies

```bash
npm install
```

## Run the server

```bash
npm start
```
